package com.finalProject.finalProjectAQE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProjectAqeApplicationTests {

	@Test
	void contextLoads() {
	}

}
